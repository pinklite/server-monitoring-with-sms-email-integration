Documentation Nodmonit
===

* Introduction
* Server
* Web UI
* Agents
* Translation
* Embedding
* Security Concerns
* Contact

Introduction
---

Nodmonit is a linux resource monitoring's software with SMS and/or email integration,
that is datacenter and cluster aware, meaning you can have your computing cloud spread across
anywhere you would like in the world and categorize it.
It's translatable, embeddable into your existing admin panel and easy to use.  

Currently its possible to monitor and be notified of:

* RAM
* LOAD
* DISK
* CPU
* SWAP
* Number of open files

Nodmonit uses a server-client approach to handle communication, meaning you have
ONE main database server that will receive the monitoring stats from MANY clients
and store it in mongodb through a HTTP API. All data is put in a database called "nodmonit".

### Requirements

For the server:
* mongodb >= 3.2
* nginx/apache or any other webserver

Beware that under Ubuntu `apt-get install mongodb` will install a deprecated version of mongodb
so check mongodb website for how to install the latest version.

For the agent
* curl

Make sure you have the above installed and mongodb running, there's plenty of documentation on the web
on how to install those.

Server
---

### Installation

After unpacking the zip file you will get 2 folders:

* server
* web

Choose the appropriate binary file inside `server/` to your linux distribution.
If you don't know which to choose, you will probably want `server/nodmonit_linux_amd64` binary,
then copy it to you main server with scp:

```sh
cd unpacked-nodmonit
scp server/nodmonit_linux_amd64 root@myserver.com:~/nodmonit
```

Now lets install it, execute the following as root inside the folder you copied the binary:

```sh
chmod +x nodmonit
mv nodmonit /usr/bin/nodmonit
useradd -m nodmonit
mkdir /etc/nodmonit.d
mkdir /var/log/nodmonit
chown -R nodmonit:nodmonit /etc/nodmonit.d
chown -R nodmonit:nodmonit /var/log/nodmonit
```

All this does so far is creating the required user and directories for nodmonit to run,
for the actual installation execute:

```sh
su - nodmonit -c "/usr/bin/nodmonit server install -mongo-host 'localhost'"
```

Should output something like:
```
Server config file located at /etc/nodmonit.d/server_config.json
Your authorization code is XXXXXXXXXXXXXXXXXX
Please, now install the frontend web ui and start adding agents.
```

That means the installation was successful. Copy the authorization code, we will use it later.
If you forget, your authorization code is located at `/etc/nodmonit.d/server_config.json`

Now start the daemon, please make sure mongodb is running before proceeding:

```
su - nodmonit -c 'nohup /usr/bin/nodmonit server daemon -http-bind localhost -http-port 9600 >>  /var/log/nodmonit/nodmonit-server.log 2>&1 &'
sleep 3
tail /var/log/nodmonit/nodmonit-server.log
```
If you see "Starting server on port 9600" nodmonit should be running and ready to accept agents. Next step is to install the web ui so you can see your admin panel.


Web UI
---
Now lets focus on the `web/` folder. The web folder contains only html, css and javascripts files, these compose the dashboard interface.

Upload the folder to your webserver.

```sh
cd unpacked-nodmonit
scp -r web root@myserver.com:/usr/share/nginx/web
```

Now login to ssh am move the folder to the nodmonit home:

```sh
mv ~/web /home/nodmonit/web
chmod a+x /home/nodmonit/web
```

Now you need to create a virtual host that serves the /home/nodmonit/web folder
and another one to proxy to the API located at http://localhost:9600

I highly recommend you to put nodmonit under its own subdomain to avoid firewall issues.

Here is a example on nginx of vhost configuration, but you can happily use apache if your more confortable:

Write the file `/etc/nginx/sites-available/nodmonit`:
```
# configure the frontend
server {
  listen 80;
  server_name nodmonit.yourserver.com;
  root /home/nodmonit/web/dist;
  include mime.types;

  location / {
    try_files $uri $uri/ /index.html;
  }
}

# configure the api endpoint
server {
  listen 80;
  server_name nodmonit-api.yourserver.com;
  location / {
    proxy_pass http://localhost:9600; # proxy to the nodmonit server
    proxy_http_version 1.1;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}
```

Now create a symlink and reload nginx

```sh
ln -s /etc/nginx/sites-available/nodmonit /etc/nginx/sites-enabled/nodmonit
nginx -sreload
```

Replace all the ".yourserver.com" to your server domain name.

Now access the following URL replacing the authorization code with the one you received before and "yourserver.com" to your server name:

http://nodmonit.yourserver.com?auth=XXXXXXXXXXXXXXXXXX&endpoint=http://nodmonit-api.yourserver.com/api

You should now see your admin panel ready to add nodes.

The following options are available to your web UI address:

* **auth**: Your authorization code
* **endpoint**: The API endpoint URL
* **skin**: light or dark. Default dark
* **displayskin**: 0 or 1. If should display the skin choice, default is 1.

Agents
---
To install an agent simply open the web ui and click on the button "New node+", copy the code, that should look something like this:

```sh
export ENDPOINT=http://nodmonit-api.yourserver.com;
export DATACENTER=;
export CLUSTER=;
curl -H 'X-Nodmonit-Auth: XXXXXXXXX' $ENDPOINT/install-agent | bash
```

Then paste it on the server you wish to monitor as root. Please make sure you have curl installed on the host.
After that, you should be able to see your node in your web ui now.

Translations
---

All translations files are located at `web/dist/assets/i18n/*` directory, check it out if a translation
for you language is available.

If not available, to translate it to your own language, copy the file `web/dist/assets/i18n/blank.json`
to `web/dist/assets/i18n/YOURLANG.json` and start translating.

After that you should tell the server to use your own translation file.
On the server edit the file `/etc/nodmonit.d/server_config.json` to look something like this:

```json
{"AuthorizationCode":"XXXXXX","MongoHost":"XXX.XXX.XXX","LangFile":"/home/nodmonit/web/dist/assets/i18n/YOURLANG.json"}
```

After that in a 30 seconds your server should update and starting showing the language of choice.
Feel free to email-me your translation file so I can include it in the package.

Embedding
---

To embed the dashboard inside your own admin panel, use the following snippet:
http://pastebin.com/vPpcaFc6

All that javascript is just so that the iframe can resize itself as you interact with it. Feel free to move to it's own file.
Also, remember replacing the variables "yourserver.name" etc..

Security Concerns
---

You may have noticed that anyone that have your auth key can access your admin panel:

http://nodmonit.yourserver.com/?**auth=XXXXXXXXXXXXXXXXXX**&endpoint=http://nodmonit.yourserver.com/api

So beware on where you make your key visible, to avoid unauthorized access.

Use HTTPS to avoid [https://en.wikipedia.org/wiki/Man-in-the-middle_attack][MITM attack]. Configuration of SSL goes
beyond this documentation, but you can get one free at [https://letsencrypt.org][Let's Encrypt].

Here is a simple example of SSL configuration using Let's Encrypt's certificate just for reference after using `./certbot-auto certonly`:

```
server {
  listen 443 ssl;
  server_name nodmonit.yourserver.com;
  root /home/nodmonit/web/dist;
  include mime.types;

  ssl_certificate /etc/letsencrypt/live/nodmonit.yourserver.com/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/nodmonit.yourserver.com/privkey.pem;
  location / {
    try_files $uri $uri/ /index.html;
  }
}

# configure the api endpoint
server {
  listen 443 ssl;
  server_name nodmonit-api.yourserver.com;

  ssl_certificate /etc/letsencrypt/live/nodmonit.yourserver.com/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/nodmonit.yourserver.com/privkey.pem;
  location / {
    proxy_pass http://localhost:9600; # proxy to the nodmonit server
    proxy_http_version 1.1;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}
```

Contact
---

Email me your address so I can notify you from future updates.

You can contact me at lucas.wxp@gmail.com for bug reports, feature requests or questions.
